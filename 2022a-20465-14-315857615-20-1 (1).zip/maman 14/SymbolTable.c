#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "SymbolTable.h"
#include "utils.h"

void add_table_item(char *key,long value,long baseadress ,long offset, symbol_type type,table *tab)
{  
   char *temp_key;
   table prev_entry, curr_entry, new_entry;
   
   new_entry = (table) malloc_with_check(sizeof(table_row)); /* allocate memory for new entry */
   temp_key = (char *) malloc_with_check(strlen(key) + 1);/* Prevent "Aliasing" of pointers.*/
   strcpy(temp_key, key);

    new_entry->key = temp_key;
    new_entry->value = value;
    new_entry->baseadress = baseadress;
    new_entry->offset = offset;
    new_entry->type = type;
     
    if ((*tab) == NULL ) /* if the table's null, set the new entry as the head. */
	{ 
		new_entry->next = (*tab);
		(*tab) = new_entry;
		return;

	}

    curr_entry = (*tab)->next; /* Insert the new table entry, keeping it sorted */
	prev_entry = *tab;
	
	while (curr_entry != NULL && curr_entry->value < value)
   {
		prev_entry = curr_entry;
		curr_entry = curr_entry->next;
	}

	new_entry->next = curr_entry;
	prev_entry->next = new_entry;
}

table filter_table_by_type(table tab, symbol_type type) 
{ /* For each entry divsion insert to the new table. */
	table new_table = NULL;
	do 
	{
		if (tab->type == type) 
		{
			add_table_item(tab->key,tab->value,tab->baseadress ,tab->offset, tab->type, &new_table);
		}
	} while ((tab = tab->next) != NULL);
	
	return new_table; /* It holds a pointer to the first entry*/
}

void free_table(table tab) /*Deallocates all the memory required by the table.*/
{
	table prev_entry, curr_entry = tab;
	while (curr_entry != NULL) 
	{
		prev_entry = curr_entry;
		curr_entry = curr_entry->next;
		free(prev_entry->key); 
		free(prev_entry);
	}
}

void add_value_to_type(table tab, long to_add, symbol_type type) 
{
	table curr_entry;
	for (curr_entry = tab; curr_entry != NULL; curr_entry = curr_entry->next) 
	{
		if (curr_entry->type == type) 
		{
			curr_entry->value += to_add;
		}
	}
}

table_row *find_by_types(table tab, char *key, int symbol_count, ...) 
{/*Find entry from the only specified types */
	int i;
	symbol_type *valid_symbol_types = malloc_with_check((symbol_count) * sizeof(int));
	/* Build a list of the valid types */
	va_list arglist;
	va_start(arglist, symbol_count);
	for (i = 0; i < symbol_count; i++) 
	{
		valid_symbol_types[i] = va_arg(arglist, symbol_type);
	}
	va_end(arglist);
	if (tab == NULL) 
	{
		free(valid_symbol_types);
		return NULL;
	}
	/* iterate over table and then over array of valid. if type is valid and same key, return the entry. */
	do {
		for (i = 0; i < symbol_count; i++) 
		{
			if (valid_symbol_types[i] == tab->type && strcmp(key, tab->key) == 0) 
			{
				free(valid_symbol_types);
				return tab;
			}
		}
	} while ((tab = tab->next) != NULL);

	free(valid_symbol_types);
	return NULL;
}



	
	

