#ifndef _MACRO_H
#define _MACRO_H

typedef struct mrow* mtable;/*pointer to table row  */

typedef struct mrow
{ 
	char *macro_name;
	char *macro_content;
    mtable next;/* Next row in the table of the macros*/
} mtable_row;

FILE *handle_macro(char *filename) ; /*going over the file and doing the macro process*/

#endif
