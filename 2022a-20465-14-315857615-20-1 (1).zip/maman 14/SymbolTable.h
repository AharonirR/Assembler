/* A dynamically-allocated symbol table */
#ifndef _SymbolTable_H
#define _SymbolTable_H

typedef enum symbol_type
{/* The symbol type */
	code_symbol,
	data_symbol,
	external_symbol,
	string_symbol,
	entry_symbol,
	none_symbol
} symbol_type;


typedef struct row* table;/*pointer to table row  */

typedef struct row {/* A single table line */

    
	char *key;/* Key (symbol name) is a string */
    long value;/*Address of the symbol */
    long baseadress; /* Address of the baseadress of the symbol*/
    long offset; /* Address of the offset */
	symbol_type type;	/* Symbol type */
    table next;/* Next row in the table of the symbol*/

} table_row;

void add_table_item(char *key,long value,long baseadress ,long offset, symbol_type type,table *tab); /*Adds an item to the table, keeping it sorted.*/

void free_table(table tab); /*Deallocates all the memory required by the table.*/

table filter_table_by_type(table tab, symbol_type type); /* Returns all the entries by their type in a new table*/

void add_value_to_type(table tab, long to_add, symbol_type type);

table_row *find_by_types(table tab,char *key, int symbol_count, ...);/*Find entry from the only specified types */

#endif