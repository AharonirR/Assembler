#ifndef _UTILS_H
#define _UTILS_H
#include "globals.h"
#include "SymbolTable.h"

/** moves the index to the next place in string where the char isn't white */
#define SKIP_WHITE(string, index) \
        for (;string[(index)] && (string[(index)] == '\t' || string[(index)] == ' '); (++(index)))\
        ;

void *malloc_with_check(long size); /* Allocates memory in the required size. Exits the program if failed.*/

int printf_error(line_info line, char *message, ...);/* error printer*/

bool checkExist(table tab, char *key);/*check if a key exist in the table already*/

bool check_int(char *string); /*checking if the char is digitl*/

bool alphanumeric_str(char *string); /*check for every char in string if it is non alphanumeric */

bool is_valid_label(char *name); /* Checking if is valid label */

bool find_label(line_info line, char *symbol_dest); /* Returns whether an error occurred during the try of parsing the symbol. puts the symbol into the second buffer. */

char *addext(char *s0, char* s1); /* add strings to each other*/

attribute find_attribute_by_name(char *name); /* recognize atrribute type and return it*/

attribute get_attribute_by_name(char *name) ;

bool is_reserved_word(char *name);

void free_code_image(machine_code **code_image, long IC, long DC); /* Frees all the dynamically-allocated memory for the code image.*/

#endif

