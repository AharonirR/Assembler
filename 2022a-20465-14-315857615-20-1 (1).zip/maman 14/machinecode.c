#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdlib.h>
#include "machinecode.h"
#include "utils.h"
#include "globals.h" 
#include"firstpass.h"

bool analyze_operands(line_info line, int i, char **dest, int *operand_count, char *c) 
{
	int j;
	*operand_count = 0;
	dest[0] = dest[1] = NULL;
	SKIP_WHITE(line.content, i);
	if (line.content[i] == ',') 
	{
		printf_error(line, "Unexpected comma after command.");
		return FALSE; /*an error*/  
	}    
    
	/* Until not too many operands (max of 2) and it's not the end of the line */
	for (*operand_count = 0; line.content[i] != EOF && line.content[i] != '\n' && line.content[i];) 
	{
		if (*operand_count == 2) /* =We already got 2 operands in, We're going ot get the third! */ 
		{   
			printf_error(line, "Too many operands for operation (got >%d)", *operand_count);
			free(dest[0]);
			free(dest[1]);
			return FALSE; /* an error  */
		}

		/* Allocate memory to save the operand */
		dest[*operand_count] = malloc_with_check(MAX_LINE_LENGTH);
		
		for (j = 0; line.content[i] && line.content[i] != '\t' && line.content[i] != ' ' && line.content[i] != '\n' && line.content[i] != EOF && line.content[i] != ','; i++, j++) 
		{
			dest[*operand_count][j] = line.content[i];
		}
        
        dest[*operand_count][j] = '\0';
        
		(*operand_count)++; /* saved another operand! */
        	
		SKIP_WHITE(line.content, i);


		if (line.content[i] == '\n' || line.content[i] == EOF || !line.content[i]) break;
		else if (line.content[i] != ',') 
		{
			printf_error(line, "Expecting ',' between operands");
			
			free(dest[0]); /* Release operands dynamically allocated memory */
			if (*operand_count > 1) 
			{
				free(dest[1]);
			}
			return FALSE;
		}
		i++;
		
		SKIP_WHITE(line.content, i);

	    if (line.content[i] == '\n' || line.content[i] == EOF || !line.content[i])
			printf_error(line, "Missing operand after comma.");
		else if (line.content[i] == ',') printf_error(line, "Multiple consecutive commas.");
		else continue; 
		{ 	
			free(dest[0]);
			if (*operand_count > 1) 
			{
				free(dest[1]);
			}
			return FALSE;
		}
	}  
	
	return TRUE;
}

typedef struct cmd_lookup_element
 { /* A single line in table element*/
	char *cmd;
	opcode op;
	funct fun;
  }cmd_lookup_element;
	 
	static struct cmd_lookup_element lookup_table[] = {
		{"mov", MOV_OP, NONE_FUNCT},
		{"cmp",CMP_OP, NONE_FUNCT},
		{"add",ADD_OP, ADD_FUNCT},
		{"sub",SUB_OP, SUB_FUNCT},
		{"lea",LEA_OP, NONE_FUNCT},
		{"clr",CLR_OP, CLR_FUNCT},
		{"not",NOT_OP, NOT_FUNCT},
		{"inc",INC_OP, INC_FUNCT},
		{"dec",DEC_OP, DEC_FUNCT},
		{"jmp",JMP_OP, JMP_FUNCT},
		{"bne",BNE_OP, BNE_FUNCT},
		{"jsr",JSR_OP, JSR_FUNCT},
		{"red",RED_OP, NONE_FUNCT},
		{"prn",PRN_OP, NONE_FUNCT},
		{"rts",RTS_OP, NONE_FUNCT},
		{"stop",STOP_OP, NONE_FUNCT},
		{NULL, NONE_OP, NONE_FUNCT}
};

void get_opcode_func(char *cmd, opcode *opcode_out, funct *funct_out) 
{
	struct cmd_lookup_element *e;
	*opcode_out = NONE_OP;
	*funct_out = NONE_FUNCT;
	/* iterate through the lookup table, if commands are same return the opcode of found. */
	for (e = lookup_table; e->cmd != NULL; e++) {
		if (strcmp(e->cmd, cmd) == 0) {
			*opcode_out = e->op;
			*funct_out = e->fun;
			return;
		}
	}
}

addressing_type get_addressing_type(char *operand) 
{ /* Returns the addressing type of an operand*/
	int i =0;
	if (operand[0] == '\0') return none_addr; /* if nothing, just return none */
    
	/* if first char is 'r', second is number in range 0-15 and third is end of string, it's a register */
	if (operand[0] == 'r' && operand[1] >= '1' && operand[2] == '\0' ) 
	return Register_addr;

    if(operand[0] == 'r' && operand[1] == '1' &&  operand[2] <= '5' && operand[3] == '\0')return Register_addr;
	
	/* if operand starts with # and a number right after that, it's immediately addressed */
	if (operand[0] == '#' && check_int(operand + 1)) 
	return Immediate_addr;
    
	while (operand[i] != '[' && operand[i] != '\n' && operand[i] != ' ' && operand[i] != '\0' && operand[i] != EOF )
	i++;
	
	if (operand[i] =='[' && operand[i+1] == 'r' && operand[i+2] <= '9' && operand[i+3] <= '5' && operand[i+4] == ']'&& operand[i+5] == '\0')  
	return index_addr;

	if (operand[i] =='[' && operand[i+1] == 'r' && operand[i+2] <= '9' && operand[i+3] == '\0') return index_addr;
   
    /* if operand is a valid label name, then check if it is index or directed */
    if (is_valid_label(operand))return Direct_addr;
    
    return none_addr;
}
 
static bool validate_op_addr(line_info line, addressing_type op1_addressing, addressing_type op2_addressing, int op1_valid_addr_count, int op2_valid_addr_count, ...) 
{
	int i;
	bool is_valid;
	va_list list; 

	addressing_type op1_valids[4], op2_valids[4];
	memset(op1_valids, none_addr, sizeof(op1_valids));
	memset(op2_valids, none_addr, sizeof(op2_valids));

	va_start(list, op2_valid_addr_count);
	/* get the variable args and put them in both arrays (op1_valids & op2_valids) */
	for (i = 0; i < op1_valid_addr_count && i <= 4 ;i++)
		op1_valids[i] = va_arg(list, int);
	for (; op1_valid_addr_count > 5; va_arg(list, int), op1_valid_addr_count--); /* Go on with stack until got all (even above limitation of 4) */
	
	
	for (i = 0; i < op2_valid_addr_count && i <= 4 ;i++)
		op2_valids[i] = va_arg(list, int);

	va_end(list);  

	/* Make the validation itself: check if any of the operand addressing type has match to any of the valid ones: */
	is_valid = op1_valid_addr_count == 0 && op1_addressing == none_addr;
	for (i = 0; i < op1_valid_addr_count && !is_valid; i++) 
	{
		if (op1_valids[i] == op1_addressing) 
		{
			is_valid = TRUE;
		}
	}

	if (!is_valid) 
	{
		printf_error(line, "Invalid addressing mode for first operand.");
		return FALSE;
	}
	
	is_valid = op2_valid_addr_count == 0 && op2_addressing == none_addr;
	for (i = 0; i < op2_valid_addr_count && !is_valid; i++) {
		if (op2_valids[i] == op2_addressing) {
			is_valid = TRUE;
		}
	}
	if (!is_valid) {
		printf_error(line, "Invalid addressing mode for second operand.");
		return FALSE;
	}
	return TRUE;
}

bool validate_operand_by_opcode(line_info line, addressing_type first_addressing,addressing_type second_addressing, opcode curr_opcode, int op_count) 
{
  if (curr_opcode >= MOV_OP && curr_opcode <= LEA_OP) 
    { 
	 if (op_count != 2) /* 2 operands required */
     {
	   printf_error(line, "Operation requires 2 operands (got %d)", op_count);
	   return FALSE;
	 }
		/* validate operand addressing */
	  if (curr_opcode == CMP_OP) 
	  {
	    return validate_op_addr(line, first_addressing, second_addressing, 4, 4, Immediate_addr, Direct_addr, index_addr, Register_addr, Immediate_addr, Direct_addr,index_addr,  Register_addr);
	  } 
	  else if (curr_opcode == ADD_OP || curr_opcode == MOV_OP || curr_opcode == SUB_OP) 
	  { 
	    return validate_op_addr(line, first_addressing, second_addressing, 4, 3, Immediate_addr, Direct_addr, index_addr, Register_addr, Direct_addr, index_addr, Register_addr);
	  } 
	  else if (curr_opcode == LEA_OP)
	  {
        return validate_op_addr(line, first_addressing, second_addressing, 2, 3, Direct_addr,index_addr, Direct_addr, index_addr, Register_addr);
	  }
    }     
  else if (curr_opcode >= CLR_OP && curr_opcode <= PRN_OP) 
    {
	  if (op_count != 1)
	    { /* 1 operand required */
			if (op_count < 1) 
            printf_error(line, "Operation requires 1 operand (got %d)", op_count);
			return FALSE;
		}
		/* validate operand addressing */
		if (curr_opcode == RED_OP || curr_opcode == CLR_OP|| curr_opcode == NOT_OP|| curr_opcode == INC_OP|| curr_opcode == DEC_OP) 
		{ 
		  return validate_op_addr(line, first_addressing, none_addr, 3, 0, Direct_addr,index_addr, Register_addr);
		} 
		else if (curr_opcode == JMP_OP|| curr_opcode == JSR_OP|| curr_opcode == BNE_OP) 
		{
		 return validate_op_addr(line, first_addressing, none_addr, 2, 0, Direct_addr, index_addr);
		} 
	    else 
		{ /* So it's PRN */
			return validate_op_addr(line, first_addressing, none_addr, 4, 0, Immediate_addr, Direct_addr, index_addr, Register_addr);
		}
	}     
  else if (curr_opcode == STOP_OP || curr_opcode == RTS_OP)
    {
	   if (op_count > 0) 
	   {/* 0 operands exactly */
		printf_error(line, "Operation requires no operands (got %d)", op_count);
		return FALSE;
		}
	}
	return TRUE;
}


reg get_register_by_name(char *name) /* Returns the register enum value by its name*/
{
  int i =0;

  if (name[0] == 'r' && isdigit(name[1]) && name[2] == '\0') 
   {
      int digit = name[1] - '0'; /* convert digit ascii char to actual single digit */
	 return digit;
   }
  if(name[0] == 'r' && name[1] == '1' &&  name[2] <= '5' && name[3] == '\0') 
  {
	 int digit = name[2]  +10 - '0'; /* convert digit ascii char to actual single digit */
	 return digit;
  }
  while (name[i] != '[' && name[i] != '\n' && name[i] != ' ' && name[i] != '\0' && name[i] != EOF )
	i++;
	
  if ( name[i] == '[' && name[i+1] == 'r' && isdigit(name[i+2]) && name[i+3] == ']'  && name[i+4] == '\0')
   {
      int digit = name[i+2] - '0'; /* convert digit ascii char to actual single digit */
	 return digit;
   }

   if (name[i] =='[' && name[i+1] == 'r' && name[i+2] <= '9' && name[i+3] <= '5' && name[i+4] == ']'&& name[i+5] == '\0')
   {
      int digit = name[i+3] +10 - '0'; /* convert digit ascii char to actual single digit */
	 return digit;
   }
	return NONE_REG; 
}

first_line_code *get_first_line_code(line_info line, int num)
{/* Builds a first line code by the opcode*/
 first_line_code *firstlinecode;
 firstlinecode = (first_line_code *) malloc_with_check(sizeof(first_line_code));
 firstlinecode->opcode = num;
 firstlinecode->ARE = 4;
 return firstlinecode;
} 

second_line_code *get_second_line_code(line_info line, opcode curr_opcode, funct curr_funct, int op_count, char *operands[2]) 
{
     second_line_code *seconedlinecode;
     /* Get addressing types and validate them: */

     /* Get addressing types and validate them: */
     /* Get addressing types and validate them: */
	
	 addressing_type first_addressing = op_count >= 1 ? get_addressing_type(operands[0]) : none_addr;
	 addressing_type second_addressing = op_count == 2 ? get_addressing_type(operands[1]) : none_addr;
  
	 /* validate operands by opcode - on failure exit */
	    if (!validate_operand_by_opcode(line, first_addressing, second_addressing, curr_opcode, op_count))
		{
		return NULL;
		}

     seconedlinecode = (second_line_code *) malloc_with_check(sizeof(second_line_code));
      seconedlinecode->funct = curr_funct; 
     seconedlinecode->ARE = 4; 

     /* Default values of register bits are 0 */
	 seconedlinecode->adressing_des = seconedlinecode->register_des = seconedlinecode->adressing_src = seconedlinecode->registesr_src = 0;
        /* Check if need to set the registers bits */
     if (curr_opcode >= MOV_OP && curr_opcode <= LEA_OP) 
	 { /* First Group, two operands */
		seconedlinecode->adressing_src = first_addressing;
		seconedlinecode->adressing_des = second_addressing;
       
       /* if it's register, set it's name in the proper locations */
	    if (first_addressing == index_addr)
		{
          seconedlinecode->registesr_src = get_register_by_name(operands[0]);
		}

		if (second_addressing == index_addr)
		seconedlinecode->register_des = get_register_by_name(operands[1]);
	 	

		if (first_addressing == Register_addr) 
		seconedlinecode->registesr_src = get_register_by_name(operands[0]);
		

		if (second_addressing == Register_addr)
		seconedlinecode->register_des = get_register_by_name(operands[1]);
		
	 }
     else if (curr_opcode >= CLR_OP && curr_opcode <= PRN_OP) 
	 {
		   seconedlinecode->adressing_des = first_addressing;

		if (first_addressing == index_addr)
		seconedlinecode->register_des = get_register_by_name(operands[0]);
		  
		if (first_addressing == Register_addr) 
		seconedlinecode->register_des = get_register_by_name(operands[0]);
		
	}
	return seconedlinecode;
}

extra_line_code *get_extra_line_code(line_info line, char* operand, long curr_baseoffset, int num)
{ /* Builds a extra line code by the base or offset adress */

        extra_line_code *extralinecode;
        extralinecode = (extra_line_code *) malloc_with_check(sizeof(extra_line_code));
        extralinecode->base_offset_addr = curr_baseoffset;
		extralinecode->ARE = num;
        return extralinecode;
}

data_digit *build_data_line(addressing_type address, long data, bool is_extern_symbol) 
{   
	long ARE = 4;
    data_digit *data_line_code = (data_digit *) malloc_with_check(sizeof(data_digit));
    if (address == Direct_addr) 
	{
    ARE = is_extern_symbol ? 1 : 2;
	}
	data_line_code->ARE = ARE; 
	data_line_code->data =data; 
	return data_line_code;
}

data_digit *get_data_line(long data) 
{   
	long ARE = 4;
    data_digit *data_line_code = (data_digit *) malloc_with_check(sizeof(data_digit));
	data_line_code->ARE = ARE; 
	data_line_code->data =data; 
	return data_line_code;
}