#include <stdio.h>
#include <stdlib.h>
#include "machinecode.h"
#include "utils.h"
#include "string.h"
#include "globals.h"

bool process_spass_operand(line_info line, long *curr_ic, long *ic, char *operand, machine_code **code_img, table *symbol_table);

bool process_spass_operand(line_info line, long *curr_ic, long *ic, char *operand, machine_code **code_img, table *symbol_table) 
{
 addressing_type addre = get_addressing_type(operand);
 machine_code *code_to_write, *codee_to_write ;
 extra_line_code *extr_line_code;
 extra_line_code *extraa_line_code;
 long base ;
 long offset;
 int x,i;
 table_row *row;
 i = 0;
 	 
 if (addre == index_addr)
 {
   while(operand[i] != '[')
   i++;
  
   operand[i] = '\0';
   addre = get_addressing_type(operand);
 }
 
 row = find_by_types(*symbol_table, operand, 4, data_symbol, code_symbol,string_symbol, external_symbol);
 
 if (addre == Immediate_addr)  
 (*curr_ic)++;

 if (Direct_addr == addre ) 
 {

   if (row == NULL)
   {
   printf_error(line, "The symbol %s not found", operand);
   return FALSE;
   }
 
  if (row->type == code_symbol || row->type == string_symbol|| row->type == data_symbol)
  x = 2;
  else
  x = 4;

  if (row->type == external_symbol)
  x = 1;
   
   /*fill the gap of base and offset adress*/
    (*curr_ic) = (*curr_ic)+ 2;
     base = row->baseadress;
     offset = row->offset;
     code_to_write = (machine_code *) malloc_with_check(sizeof(machine_code));
     extr_line_code = get_extra_line_code(line,operand,base,x);
     code_to_write->extra = extr_line_code;
     code_img[(*curr_ic) - IC_VALUE] = code_to_write;
     code_img[(*curr_ic) - IC_VALUE]->Separator = 3;
   
     (*curr_ic)++;
     codee_to_write = (machine_code *) malloc_with_check(sizeof(machine_code));
     extraa_line_code = get_extra_line_code(line, operand, offset, x);
     codee_to_write->extra = extraa_line_code;
     code_img[(*curr_ic) - IC_VALUE] = codee_to_write;
     code_img[(*curr_ic) - IC_VALUE]->Separator = 3;

	 if (row->type == external_symbol)
  {/*update the info of the externals symbols*/
  row->value = *curr_ic;	
  row->baseadress= (*curr_ic) - 1;
  row->offset=(*curr_ic) ;
  }
 }
    return TRUE;
}

bool add_symbols_to_code(line_info line, long *ic, machine_code **code_img, table *symbol_table) 
{
	char temp[80];
	char *operands[2];
	int i = 0, operand_count;
	bool isvalid = TRUE;
	long curr_ic = *ic; /* using curr_ic as temp index inside the code image*/
	
	/* Get the total word length of current code text line in code binary image */
	int length = code_img[(*ic) - IC_VALUE]->length;
    
	if (length > 1)
	{ 	
		SKIP_WHITE(line.content, i) /* Now, we need to skip command, and get the operands themselves: */
	 	find_label(line, temp);
		if (temp[0] != '\0') 
		{ /* if symbol is defined */
			/* move i right after it's end */
			for (; line.content[i] && line.content[i] != '\n' && line.content[i] != EOF && line.content[i] != ' ' && line.content[i] != '\t'; i++);
		}
		SKIP_WHITE(line.content, i)
		/* now skip command */
		for (; line.content[i] && line.content[i] != ' ' && line.content[i] != '\t' && line.content[i] != '\n' && line.content[i] != EOF; i++);
		SKIP_WHITE(line.content, i)
		/* now analyze operands We send NULL as string of command because no error will be printed, and that's the only usage for it there. */
		analyze_operands(line, i, operands, &operand_count, NULL);
	
      /* Process operands, if needed. if failed return failure. otherwise continue */
      if (operand_count--) 
     {
      isvalid = process_spass_operand(line, &curr_ic, ic, operands[0], code_img, symbol_table);
      free(operands[0]);
      if (!isvalid) return FALSE;
      if (operand_count) 
	  {
      isvalid = process_spass_operand(line, &curr_ic, ic, operands[1], code_img, symbol_table);
      free(operands[1]);
      if (!isvalid) return FALSE;
      }
     }
    }
 /* Make the current pass IC as the next line ic */
 (*ic) = (*ic) + length;
 return TRUE;
}


bool process_line_spass(line_info line, long *ic, machine_code **code_img, table *symbol_table) 
{ 
    char *indexOfColon;
	char *token;
	long i = 0;
	SKIP_WHITE(line.content, i)
    
	if (line.content[i] == ';' || line.content[i] == '\n') return TRUE; /* Empty/Comment line  step 2.1*/
	
    indexOfColon = strchr(line.content, ':'); /* check and skip label step 2.2 */
	if (indexOfColon != NULL) 
    {
		i = indexOfColon - line.content;
		i++;
	}
	SKIP_WHITE(line.content, i)

	/* 2.3-2.5 steps */
	if (line.content[i] == '.') 
    {
		/*if it's entry we add it to the symbol table step 2.5*/
		if (strncmp(".entry", line.content, 6) == 0) 
        {
			i += 6;
			SKIP_WHITE(line.content, i)
			token = strtok(line.content + i, " \n\t");
			/* if label is already marked as entry, ignore. */
			if (token == NULL)
            {
				printf_error(line, "You have to specify a label name for .entry instruction.");
				return FALSE;
			}

			if (find_by_types(*symbol_table, token, 1, entry_symbol) == NULL) 
            {
				table_row *row;
				token = strtok(line.content + i, "\n"); /*get name of label*/
				if (token[0] == '&') token++;
				if ((row = find_by_types(*symbol_table, token, 2, data_symbol, code_symbol)) == NULL) 
                {/* if symbol is not defined as data/code */
					if ((row = find_by_types(*symbol_table, token, 1, external_symbol)) != NULL) 
                    {/* if defined as external print error */
						printf_error(line, "The symbol %s can be either external or entry, but not both.", row->key);
						return FALSE;
					}
					/* otherwise print more general error */
					printf_error(line, "The symbol %s for .entry is undefined.", token);
					return FALSE;
				}
				 add_table_item(token,row->value,row->baseadress ,row->offset, entry_symbol,symbol_table);
			}
		}
		return TRUE;
	}
	return add_symbols_to_code(line, ic, code_img, symbol_table);/*step 2.6*/
}