#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "firstpass.h"
#include "secondpass.h"
#include "outofile.h"
#include "utils.h"
#include "macro.h"
#include "outofile.h"


static bool process_file(char *filename);

int main(int argc, char *argv[]) {
	int i;
	bool succeeded = TRUE;
	for (i = 1; i < argc; ++i) {
    if (!succeeded) puts("");
    succeeded = process_file(argv[i]);
		
	}
	return 0;
}

static bool process_file(char *filename) 
{
	int temp_c;
	long ic = IC_VALUE, dc = 0, icf, dcf; /* Memory address counters */
    
	bool checking_success = TRUE; /* for chechking later if the pass are correct*/
    
	char *input_filename;
	char temp_line[MAX_LINE_LENGTH +1]; /* temporary string for storing line */
    long data_img[8191]; /* Contains an image of the machine code array of lines*/
	machine_code *code_img[8191];
	table symbol_table = NULL; /* The symbol table */
	line_info curr_line_info;
	FILE *file_after_macro;/* Current assembly file descriptor to process after the macros pass */
	input_filename = addext(filename,".am");
	file_after_macro = handle_macro(filename);
    	

	/* start first pass*/
    curr_line_info.file_name = input_filename;
	curr_line_info.content = temp_line; /* We use temp_line to read from the file, but it stays at same location. */
      
    /* loop which running over the line's file */
	for (curr_line_info.line_num = 1;fgets(temp_line, MAX_LINE_LENGTH + 1, file_after_macro) != NULL; curr_line_info.line_num++) 
	{
		fgets(temp_line,80, file_after_macro);
		if(temp_line[0] == '0')
		checking_success = FALSE; 
	}
    
    rewind(file_after_macro);

     /* start first pass*/
    if (checking_success) 
	{
	 curr_line_info.file_name = input_filename;
	 curr_line_info.content = temp_line; /* We use temp_line to read from the file, but it stays at same location. */
	
     /* loop which running over the line's file */
	 for (curr_line_info.line_num = 1;fgets(temp_line, MAX_LINE_LENGTH + 1, file_after_macro) != NULL; curr_line_info.line_num++) 
     {
		/* if line too long, the buffer doesn't include the '\n' char OR the file isn't on end. */
		if (strchr(temp_line, '\n') == NULL && !feof(file_after_macro)) 
        {
            printf_error(curr_line_info, "Line too long to process,the maximum line length should be %d.",80);
			checking_success = FALSE; /* Print error message  nd prevent further line processing */
			do {
				temp_c = fgetc(file_after_macro);
			} while (temp_c != '\n' && temp_c != EOF);
		} 
		else 
		{
			if (!process_line_fpass(curr_line_info, &ic, &dc, code_img, data_img, &symbol_table)) 
			{ /* steps 1.01 -1.17 in algo */
				if (checking_success) 
				{
					/*free_code_image(code_img, ic_before);*/
					icf = -1; 
					checking_success = FALSE;
				}
			}
	    }
	 }	
     /* Save ICF & DCF step 1.18 in the algo */
	 icf = ic;
	 dcf = dc;
	}
	/* if first pass didn't fail, start the second pass */
	if (checking_success) 
	{
      ic = IC_VALUE;
     /* step 1.19 in the algo */
	 add_value_to_type(symbol_table, icf, data_symbol);
	  
     /*second pass */
     rewind(file_after_macro); /* Start from beginning of file again */

	 for (curr_line_info.line_num = 1; !feof(file_after_macro); curr_line_info.line_num++) 
	 {
		int i = 0;
		fgets(temp_line,80, file_after_macro); /* Get line */
		SKIP_WHITE(temp_line, i);
        
		if (code_img[ic - IC_VALUE] != NULL || temp_line[i] == '.')
		{
			checking_success &= process_line_spass(curr_line_info, &ic, code_img, &symbol_table);
		}
		
	 }
       /* Write files if second pass succeeded */
		if (checking_success) 
		{
			/* Everything was done. Write to *filename.ob/.ext/.ent */
			checking_success = output_files(code_img, data_img, icf, dcf, filename, symbol_table);
		}
	}
	free(input_filename);
	free_table(symbol_table);
	
	free_code_image(code_img, icf, dcf);

	return checking_success;
}
