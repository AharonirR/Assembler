#ifndef _FIRST_PASS_H
#define _FIRST_PASS_H
#include "globals.h"
#include "SymbolTable.h"

/* Processes a single line in the first pass*/
bool process_line_fpass(line_info line, long *IC, long *DC, machine_code **code_img, long *data_img,  table *symbol_table);

#endif