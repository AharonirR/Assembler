#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "utils.h"
#include "SymbolTable.h"
#include "machinecode.h"

static bool write_ob(machine_code **code_img, long *data_img, long icf, long dcf, char *filename);

int output_files(machine_code **code_img, long *data_img, long icf, long dcf, char *filename, table symbol_table);


static bool write_ob(machine_code **code_img, long *data_img, long icf, long dcf, char *filename)
{
	int ICF;
	int i,j;
	int a,b,c,d,e,x,y,z,w;
	FILE *file_desc;
	machine_code *data_image;
	data_digit *data_line_code;
	char *output_filename = addext(filename, ".ob"); /* add extension of file to open */
	file_desc = fopen(output_filename, "w"); /* Try to open the file for writing */
    free(output_filename);
  
	if (file_desc == NULL) 
	{
		fprintf(stderr ,"Can't create or rewrite to file %s.", output_filename);
		return FALSE;
	}

    ICF = icf -IC_VALUE- dcf;
    fprintf(file_desc, "               %d %ld", ICF, dcf); /* print data/code word count on top */
     
   for (i = 0; i < icf - IC_VALUE -dcf; i++) 
   {   
	  if (code_img[i]->Separator == 1)  
	  {   
		  a = ((code_img[i]->first->ARE)) ;
		  b = ((code_img[i]->first->opcode >> 12) & 15) ;
		  c = ((code_img[i]->first->opcode >> 8) & 15)  ;
		  d = ((code_img[i]->first->opcode >> 4) & 15)  ;
          e = ((code_img[i]->first->opcode) & 15) ;
	      fprintf(file_desc, "\n 0%d A%x-B%x-C%x-D%x-E%x", i + 100,a,b,c,d,e);
	  }       
       if (code_img[i]->Separator == 2)  
	   { 
	      a = ((code_img[i]->second->ARE));
		  b = (code_img[i]->second->funct);
		  c = (code_img[i]->second->registesr_src);
		  x = ((code_img[i]->second->register_des) >> 2);
		  if((code_img[i]->second->adressing_src) == 0 )
		  y = 0;
		  if((code_img[i]->second->adressing_src) == 1 )
		  y = 4;
		  if((code_img[i]->second->adressing_src) == 2 )
		  y = 8;
		  if((code_img[i]->second->adressing_src) == 3 )
		  y = 12;
		  d = x + y;
		  w = (code_img[i]->second->adressing_des);
		  z = (((code_img[i]->second->register_des) << 2)& 15);
		  e = w +z ;
	      fprintf(file_desc, "\n 0%d A%x-B%x-C%x-D%x-E%x", i + 100,a,b,c,d,e);
	    }
	  
     if (code_img[i]->Separator == 3) 
	 {  
	      a = ((code_img[i]->extra->ARE));
		  b = ((code_img[i]->extra->base_offset_addr >> 12) & 15) ;
		  c = ((code_img[i]->extra->base_offset_addr >> 8) & 15)  ;
		  d = ((code_img[i]->extra->base_offset_addr >> 4) & 15) ;
          e = ((code_img[i]->extra->base_offset_addr) & 15) ; 
	     fprintf(file_desc, "\n 0%d A%x-B%x-C%x-D%x-E%x", i + 100,a,b,c,d,e);
	 }

	  if (code_img[i]->Separator == 0) 
	 { 
	      a = ((code_img[i]->data->ARE));
		  b = ((code_img[i]->data->data >> 12) & 15)  ;
		  c = ((code_img[i]->data->data >> 8) & 15) ;
		  d = ((code_img[i]->data->data >> 4) & 15)  ;
          e = ((code_img[i]->data->data) & 15); 
	     fprintf(file_desc, "\n 0%d A%x-B%x-C%x-D%x-E%x", i + 100,a,b,c,d,e);
	 } 
    }

    data_image = (machine_code *) malloc_with_check(sizeof(machine_code));               
	for (j = 0; j < dcf; j++) 
	{
		data_line_code = get_data_line(data_img[j]);
		data_image->data = data_line_code;
		code_img[i] = data_image;
		a = ((code_img[i]->data->ARE));
		b = ((code_img[i]->data->data >> 12) & 15)  ;
	    c = ((code_img[i]->data->data >> 8)  & 15) ;
		d = ((code_img[i]->data->data >> 4) & 15)  ;
        e = ((code_img[i]->data->data) & 15) ; 
	    fprintf(file_desc, "\n 0%d A%x-B%x-C%x-D%x-E%x", i + 100,a,b,c,d,e);
	     i++;
	}

	/* Close the file */
	free(data_image);
	fclose(file_desc);
	return TRUE;
}

 static bool write_ent(table tab, char *filename)
 {
	FILE *file_desc;
	char *full_filename = addext(filename, ".ent");
	file_desc = fopen(full_filename, "w");
	free(full_filename);
	if (file_desc == NULL) 
	{
		fprintf(stderr, "Can't create or rewrite to file %s.", full_filename);
		return FALSE;
	}
	if (tab == NULL) return TRUE;
  
	fprintf(file_desc, "%s ,%.ld, %.ld", tab->key, tab->baseadress, tab->offset);
	while ((tab = tab->next) != NULL) 
	{
		fprintf(file_desc, "\n%s,%.ld,%.ld", tab->key, tab->baseadress, tab->offset);
	}
	fclose(file_desc);
	return TRUE;
 }

static bool write_ext(table tab, char *filename) 
{
	FILE *file_desc;
	char *full_filename = addext(filename, ".ext");
	file_desc = fopen(full_filename, "w");
	free(full_filename);
	if (file_desc == NULL) 
	{
		fprintf(stderr,"Can't create or rewrite to file %s.", full_filename);
		return FALSE;
	}
	if (tab == NULL) return TRUE;
    
	fprintf(file_desc, "%s BASE %.ld ",tab->key, tab->baseadress);
	fprintf(file_desc, "\n%s OFFSET %.ld\n", tab->key, tab->offset);
	while ((tab = tab->next) != NULL) 
	{
		fprintf(file_desc, "\n%s BASE %.ld" , tab->key, tab->baseadress);
	    fprintf(file_desc, "\n%s OFFSET %.ld" , tab->key, tab->offset);
	}
	fclose(file_desc);
	return TRUE;
}
    

int output_files(machine_code **code_img, long *data_img, long icf, long dcf, char *filename, table symbol_table)
{
	bool result;
	table externals = filter_table_by_type(symbol_table, external_symbol);
	table entries = filter_table_by_type(symbol_table, entry_symbol);
	result = write_ext(externals, filename) && write_ent(entries, filename) && write_ob(code_img, data_img, icf, dcf, filename);
	free_table(externals);
	free_table(entries);
	return result;
}

