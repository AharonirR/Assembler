#ifndef SECOND_PASS_H
#define _SECOND_PASS_H
#include "globals.h"
#include "SymbolTable.h"

/* Processes a single line in the second pass*/
bool process_line_spass(line_info line, long *ic, machine_code **code_img, table *symbol_table);

#endif

