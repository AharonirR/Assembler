#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "macro.h"
#include "utils.h"

bool checking_macro_name(char *macro_name)
{   

	if(strcmp(macro_name, "mov") == 0)
	return FALSE;
	if(strcmp(macro_name, "cmp") == 0)
	return FALSE;
	if(strcmp(macro_name, "add") == 0)
	return FALSE;
	if(strcmp(macro_name, "sub") == 0) 
	return FALSE;
	if(strcmp(macro_name, "lea") == 0)
	return FALSE;
	if(strcmp(macro_name, "clr") == 0)
	return FALSE;
	if(strcmp(macro_name, "not") == 0)
	return FALSE;
	if(strcmp(macro_name, "inc") == 0)
	return FALSE;
	if(strcmp(macro_name, "dec") == 0)
	return FALSE;
	if(strcmp(macro_name, "bne") == 0)
	return FALSE;
	if(strcmp(macro_name, "jsr") == 0)
	return FALSE;
	if(strcmp(macro_name, "red") == 0)
	return FALSE;
	if(strcmp(macro_name, "prn") == 0)
	return FALSE;
	if(strcmp(macro_name, "rts") == 0)
	return FALSE;
	if(strcmp(macro_name, "stop") == 0)
	return FALSE;
	if(strcmp(macro_name, "string") == 0)
	return FALSE;
	if(strcmp(macro_name, "data") == 0)
	return FALSE;
	if(strcmp(macro_name, "entry") == 0)
	return FALSE;
	if(strcmp(macro_name, "extern") == 0)
	return FALSE;

	return TRUE;
}

void free_mtable(mtable mtab) /*Deallocates all the memory required by the table.*/
{	
	mtable prev_entry = mtab; 
	mtable curr_entry = mtab;
	while (curr_entry != NULL) 
	{
		prev_entry = curr_entry;
		curr_entry = curr_entry->next;
		free(prev_entry);
	}
}

bool is_macro_reserved(char *macro_name, mtable mtab)
{
  mtable curr_entry;
  curr_entry = mtab;
  while (curr_entry != NULL)
    {
     if(curr_entry->macro_name != NULL)
	 {
		if((strcmp(macro_name,curr_entry->macro_name)) == 0)
		 return FALSE;
	 }
	
	curr_entry = curr_entry->next;
	} 
	return TRUE;
	
}

bool checking_macro_declration(char *line)
{
  char *the_line = line;
  char word[MAX_LINE_LENGTH];
  char macro_name[MAX_LINE_LENGTH];
  int i,j,l;
  i = 0, j=0, l=0;
  
  SKIP_WHITE(the_line, i);/* get the first word in the line*/
  
  if (!the_line[i] || the_line[i] == '\n' || the_line[i] == EOF || the_line[i] == ';')
		return TRUE; /* Empty/Comment line */
  
	    while (the_line[i] != ' ' && the_line[i] != '\n' && i <= 80) 
	{
		word[j] = the_line[i];
		i++, j++; 
	}
      word[j] = '\0'; /* End of string */
     
	 
     if((strcmp( word, "macro")) != 0) /*checking if there is macro*/
     return TRUE;
    
     SKIP_WHITE(the_line, i); /* moving to macro name*/
      
    if (!the_line[i] || the_line[i] == '\n' || the_line[i] == EOF || the_line[i] == ';')
    {
         fprintf(stderr ,"error :there is no name after macro declaraion \n");
		 return TRUE; /* Empty/Comment line */
    }
	
	while (the_line[i] != ' ' && the_line[i] != '\n' && i <= 80)  /*checking if there is macro*/
	{
		macro_name[l]= the_line[i];
		i++, l++;
	}
	    macro_name[l]= '\0';

    if(!checking_macro_name(macro_name))
    {
     fprintf(stderr,"The macro name can't be instruction name or operand name: %s \n" , macro_name); 
	 return TRUE;
    }
    
    SKIP_WHITE(the_line, i);
      
    if (!the_line[i] || the_line[i] == '\n' || the_line[i] == EOF || the_line[i] == ' ')
    return FALSE;

   fprintf(stderr,"error: after macro declarion there no more words at the same line \n"); 
   return TRUE;
}

void add_mtable_item(char *key,char *content, mtable *mtab)
{  
   char *temp_key;
   char *temp_content;
   mtable prev_entry, curr_entry, new_entry;
   
   new_entry = (mtable) malloc_with_check(sizeof(mtable_row)); /* allocate memory for new entry */
   temp_key = (char *) malloc_with_check(strlen(key) + 1);/* Prevent "Aliasing" of pointers.*/
   temp_content = (char *) malloc_with_check(strlen(content) + 1);/* Prevent "Aliasing" of pointers.*/
   strcpy(temp_key, key);
   strcpy(temp_content, content);
  
    new_entry->macro_name = temp_key;
    new_entry->macro_content = temp_content;
    
     
    if ((*mtab) == NULL ) /* if the table's null, set the new entry as the head. */
	{ 
		new_entry->next = (*mtab);
		(*mtab) = new_entry;
		new_entry = NULL;
		return;

	}

    curr_entry = (*mtab)->next; 
	prev_entry = *mtab;

	new_entry->next = curr_entry;
	prev_entry->next = new_entry;

	free_mtable(new_entry);
	
}

FILE *handle_macro(char *filename) 
{   
    mtable macro_table;
	int m,l,i,j;
	int temp_c;
	int result; 
    
	char temp_line[MAX_LINE_LENGTH +1]; /* temporary string for storing line */
	char check_endm[MAX_LINE_LENGTH+1] ;
	char check_macro[MAX_LINE_LENGTH+1] ;

	line_info curr_line_info;
	line_info output_file_line_info;
    FILE *fd;
	FILE *new_fd; 
	char *input_filename = addext(filename, ".am");
	fd = fopen(filename, "r+");
    new_fd = fopen(input_filename, "w+");
	i=0;

	if (fd == NULL ) 
	{ /* if file couldn't be opened, write to stderr */
		fprintf(stderr,"cannot open file \n");
		free(fd);  
		return NULL;
    }
     
	if (new_fd == NULL ) 
	{ /* if file couldn't be opened, write to stderr */
		fprintf(stderr,"cannot open file \n");
		free(new_fd);  
		return NULL;
    }
   
    macro_table = (mtable)malloc_with_check(sizeof(mtable_row)); /* allocate memory  */
    macro_table = NULL;

    curr_line_info.file_name = filename;
	output_file_line_info.file_name = input_filename;
	curr_line_info.content = temp_line; /* We use temp_line to read from the file, but it stays at same location. */
    
	for (curr_line_info.line_num = 1;fgets(temp_line, MAX_LINE_LENGTH + 1, fd) != NULL; curr_line_info.line_num++) 
    {/*running of the file*/
	    char macro_content[655280];
		char macro_name[MAX_LINE_LENGTH+1] ;
        
		i=0,m=0,l=0,j=0;
		if (strchr(temp_line, '\n') == NULL && !feof(fd)) 
        {/* if line too long, the buffer doesn't include the '\n' char OR the file isn't on end. */
            fprintf(new_fd, "%d" ,0);
			output_file_line_info.line_num++;
		    return NULL;
			do {
				temp_c = fgetc(fd);
			} while (temp_c != '\n' && temp_c != EOF);
		} 
		else
		{	   
            if(!checking_macro_declration(temp_line))/*checking if its the right way to declare a macro*/
		    { 
			  
			  i= 5;
			  SKIP_WHITE(temp_line,i);

             while (temp_line[i] != ' ' && temp_line[i] != '\n' && i <= 80) /*checking if there is macro*/
	         {
			  macro_name[j] = temp_line[i];
		      i++, j++; 
	         }
             macro_name[j] = '\0'; /* End of string */
			
             for (;fgets(temp_line, MAX_LINE_LENGTH +1 , fd) != NULL; curr_line_info.line_num++) 
			    {
				  i=0,l=0;

				  SKIP_WHITE(temp_line,i)
			      
                  while (temp_line[i] != ' ' && temp_line[i] != '\n' && i <= 80) /* get the firt word in the line of the macro*/
			      {
		           check_endm[l] = temp_line[i];
		           i++, l++; 
	              }
                 check_endm[l] = '\0'; /* End of string */
               
                 result= strcmp(check_endm,"endm"); 
				  
				 if(result == 0)
				 {
				 curr_line_info.line_num++;
				 break;
				 }

                 i=0;
	           
			      while (temp_line[i] != EOF && temp_line[i] != '\n') /* get the content of the macro*/
			     {
		          macro_content[m] = temp_line[i];
		          i++, m++; 
	             }
                  macro_content[m] = '\n';
                  m++;                  
			    
                   macro_content[m] = '\0';/* End of string */
				  }
				  add_mtable_item(macro_name ,macro_content, &macro_table);
                   
				 
				  output_file_line_info.line_num++;
				
			}  
		    else
		    {
				SKIP_WHITE(temp_line,i);
            	
		     while (temp_line[i] != ' ' && temp_line[i] != '\n' && i <= 80) /* saving the first word in the line*/
		     {   
		         check_macro[l] = temp_line[i];
		         i++, l++; 
	         }
			  check_macro[l] = '\0';
            
			   if(!is_macro_reserved(check_macro, macro_table))/* check if the first word in the line is macro name which is already reserved*/
				{
				 if(macro_table->macro_content !=NULL)
			     fprintf(new_fd, "%s" ,macro_table->macro_content);
				}
			     else
				    fprintf(new_fd, "%s" ,temp_line); /*print the line into the file */
					output_file_line_info.line_num++;
			}
		}
	}   
	    free_mtable(macro_table);
		fclose(fd);
		return new_fd ;
}


  









		

